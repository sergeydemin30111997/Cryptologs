<?php

namespace App\Http\Controllers\AuthTelegram;

use App\Http\Controllers\AbstractController as HomeController;
use Illuminate\Http\Request;

abstract class AbstractController extends HomeController
{
    //
}
