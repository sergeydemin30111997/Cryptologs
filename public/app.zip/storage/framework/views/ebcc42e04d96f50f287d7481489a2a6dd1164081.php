<?php $__env->startSection('title', 'Профиль'); ?>



<?php $__env->startSection('header'); ?>
    <?php $__env->startPush('modal_sum_balance'); ?>
        <div class="modal_window" id="modal_sum_balance">
            <button class="close mx_button_act-openmodalwindow" target_modal_id="modal_sum_balance">x
            </button>
            <h4 class="ttl">Добавление баланса</h4>
            <form class="def_form" style="width: 343px" action="<?php echo e(route('user_data.update', $data_user->id)); ?>"
                  method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <p class="txt">Сообщение</p>
                <textarea type="text" name="message" class="default_input"></textarea>
                <p class="txt">Введите сумму</p>
                <input type="number" name="balance_sum" class="default_input">
                <button type="submit" class="submit_button">Сохранить</button>
            </form>
        </div>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('modal_replace_balance'); ?>
        <div class="modal_window" id="modal_replace_balance">
            <button class="close mx_button_act-openmodalwindow" target_modal_id="modal_replace_balance">x
            </button>
            <h4 class="ttl">Замена баланса</h4>
            <form class="def_form" style="width: 343px" action="<?php echo e(route('user_data.update', $data_user->id)); ?>"
                  method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <p class="txt">Сообщение</p>
                <textarea type="text" name="message" class="default_input"></textarea>
                <p class="txt">Введите сумму</p>
                <input type="number" name="balance_replace" class="default_input" value="<?php echo e($data_user->balance); ?>">
                <button type="submit" class="submit_button">Сохранить</button>
            </form>
        </div>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="dashboard_content">
        <?php if(Route::is('user_data.show')): ?>
            <aside class="admin_functions_section">
                <h4 class="title">Админ-функции</h4>
                <section class="adminfunc adminfunc_givearole">
                    <h5 class="adminfunc_title">Выдать роль</h5>
                    <form class="applyuser" action="<?php echo e(route('user_data.update', $data_user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <select name="role" class="select">
                            <?php $__currentLoopData = $all_roles_in_database; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $role_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user_role == $role): ?>
                                        <option value="<?php echo e($role); ?>"
                                                selected><?php echo e($role); ?></option>
                                    <?php else: ?>
                                        <option
                                            value="<?php echo e($role); ?>"><?php echo e($role); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit" class="select_submit">Применить</button>
                    </form>
                    <div class="act_buttons">
                        <button class="mx_button mx_button_act-openmodalwindow"
                                target_modal_id="modal_replace_balance">Поменять баланс
                        </button>
                        <button class="mx_button mx_button_act-openmodalwindow"
                                target_modal_id="modal_sum_balance">Добавить к балансу
                        </button>
                        <form action="<?php echo e(route('user_data.update', $data_user->id)); ?>"
                              method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <?php if($data_user->banned == 0): ?>
                                <input type="hidden" name="banned" value="1">
                                <button type="submit" class="red">Забанить</button>
                            <?php else: ?>
                                <input type="hidden" name="banned" value="0">
                                <button type="submit" class="green">Разбанить</button>
                            <?php endif; ?>
                        </form>
                    </div>
                </section>
            </aside>
            <br>
        <?php endif; ?>
        <aside class="profile_sidebar_main" id="profile_sidebar_main">
            <div class="profile_sidebar-balance">
                <p>Баланс:</p>
                <p><b>$<?php echo e($data_user->balance); ?></b></p>
            </div>
            <section class="profile_minibar">
                <div class="icon">
                    <img src="<?php echo e($data_user->photo_telegram); ?>">
                </div>
                <div class="tprows">
                    <p><b><?php echo e($data_user->name_telegram); ?></b></p>
                    <p><?php echo e($data_user->getRoleNames()->first()); ?></p>
                </div>
            </section>
            <div class="hr_gripline"></div>
            <div class="profile_registrationinfo">
                <div class="cell">
                    <p class="ttl">Последний онлайн</p>
                    <p class="val"><?php echo e($data_user->last_time_online); ?></p>
                </div>
                <div class="cell">
                    <p class="ttl">Телеграм ID</p>
                    <p class="val"><?php echo e($data_user->id_telegram); ?></p>
                </div>
            </div>
            <div class="hr_gripline"></div>
            <form class="form-fullsized" action="<?php echo e(route('user_data.update', $data_user->id)); ?>"
                  method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <h3 class="ttl">Реквизиты для вывода</h3>
                <p class="desc">Заполняется минимум 1, изменить можно только обратившись к администратору.</p>
                <div class="iconofied_input">
                    <input type="text" placeholder="Введите BTC" name="payment_desc[BTC]"
                           <?php if(!empty($data_user->payment_desc['BTC'])): ?> value="<?php echo e($data_user->payment_desc['BTC']); ?>" <?php endif; ?>>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
                        <g>
                            <path
                                d="M17.9986 8.84482C18.0862 13.815 14.1263 17.9123 9.15495 17.9983C4.18848 18.0938 0.0843045 14.1258 0.00150592 9.16204C-0.0885547 4.18861 3.87221 0.0887251 8.84009 0.00135776C13.8124 -0.0840819 17.9122 3.87351 17.999 8.84627L17.9986 8.84482ZM12.5001 6.73514C12.3652 5.53643 11.3183 5.14898 9.9981 5.05218L9.97136 3.38728L8.95413 3.40348L8.98281 5.03213C8.71586 5.03608 8.43938 5.04801 8.16306 5.05757L8.13122 3.41422L7.11037 3.43139L7.13944 5.10499C6.91986 5.11177 6.70428 5.11904 6.49175 5.12316L5.08881 5.14948L5.10839 6.23694C5.10839 6.23694 5.85878 6.21068 5.84642 6.22253C6.26061 6.2172 6.39744 6.45237 6.44095 6.65817L6.52014 11.2345C6.49802 11.3694 6.42504 11.5753 6.13609 11.5813C6.15085 11.5929 5.39366 11.5938 5.39366 11.5938L5.20854 12.8161L6.53071 12.7927L7.25179 12.7875L7.28572 14.4792L8.30598 14.4599L8.27594 12.7827C8.55629 12.7852 8.82384 12.7835 9.09002 12.7766L9.1387 14.4364L10.1595 14.4193L10.1292 12.7266C11.8358 12.6011 13.0277 12.1498 13.1479 10.5403C13.2431 9.24342 12.625 8.67662 11.645 8.46073C12.2266 8.15507 12.5847 7.6188 12.4879 6.73607L12.4951 6.73413L12.5001 6.73514ZM11.138 10.3773C11.1637 11.6441 8.99538 11.5337 8.3054 11.5477L8.26404 9.30659C8.95815 9.29928 11.1173 9.06263 11.138 10.3773ZM10.6117 7.22545C10.6329 8.37694 8.82496 8.27487 8.25049 8.28508L8.2118 6.24516C8.78602 6.23114 10.5873 6.01579 10.6098 7.2213L10.6117 7.22545Z"/>
                        </g>
                    </svg>
                </div>
                <div class="iconofied_input">
                    <input type="text" placeholder="Введите ETH (ERC-20)" name="payment_desc[ETH]"
                           <?php if(!empty($data_user->payment_desc['ETH'])): ?> value="<?php echo e($data_user->payment_desc['ETH']); ?>" <?php endif; ?>>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
                        <path
                            d="M8.95806 13.4775L3.43506 10.215L8.95731 18L14.4848 10.215L8.95581 13.4775H8.95806ZM9.04206 0L3.51756 9.16725L9.04131 12.4327L14.5651 9.17025L9.04206 0Z"/>
                    </svg>
                </div>
                <div class="iconofied_input">
                    <input type="text" placeholder="Введите XMR" name="payment_desc[Monero]"
                           <?php if(!empty($data_user->payment_desc['Monero'])): ?> value="<?php echo e($data_user->payment_desc['Monero']); ?>" <?php endif; ?>>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
                        <path
                            d="M9 0C4.02375 0 0 4.02975 0 9.01125C0 10.0125 0.171 10.9665 0.4635 11.8687H3.14625V4.29675L9 10.1588L14.8538 4.2975V11.8687H17.5365C17.8283 10.9665 18 10.0125 18 9.01125C18 4.03125 13.9762 0 9 0ZM7.659 11.4803L5.09625 8.9145V13.6777H1.3185C2.9025 16.2668 5.7585 18 9 18C12.2415 18 15.1215 16.2668 16.6838 13.677H12.9037V8.91375L10.3643 11.4795L9.02325 12.822L7.66275 11.4795H7.659V11.4803Z"/>
                    </svg>
                </div>
                <button type="submit" class="complete_wallets_main hidden btn green">Применить</button>
                <?php if($data_user->payment_desc !== null && Route::is('profile')): ?>
                    <button type="button" class="btn purple mx_button mx_button_act-openmodalwindow"
                            target_modal_id="modal_create_payment_request">Запросить выплату
                    </button>
                <?php endif; ?>
            </form>
        </aside>
        <div class="mx_title">
            <h2 class="ttl">Выплаты</h2>
            <p class="desc">История о последних выплатах</p>
        </div>
        <div class="dash_list">
            <div class="row row-title">
                <div class="cell">
                    №
                </div>
                <div class="cell">
                    Сумма
                </div>
                <div class="cell">
                    статус
                </div>
                <div class="cell">
                    время
                </div>
            </div>
            <?php if(!empty($history_payments)): ?>
                <?php $__currentLoopData = $history_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_history_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="cell">
                            <?php echo e($item_history_payment->id); ?>

                        </div>
                        <div class="cell">
                            <?php echo e('$'.$item_history_payment->sum); ?>

                        </div>
                        <div class="cell">
                            <?php if($item_history_payment->status_payment == 'payout'): ?>
                                <div class="status_span status_span-green">
                                    <?php echo e(__('payment_requests.'.$item_history_payment->status_payment)); ?>

                                </div>
                            <?php else: ?>
                                <div class="status_span status_span-red">
                                    <?php echo e(__('payment_requests.'.$item_history_payment->status_payment)); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="cell">
                            <?php echo e($item_history_payment->created_at->format('G:i:s j.m.Y')); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <br>
        <div class="mx_title">
            <h2 class="ttl">История аккаунта</h2>
            <p class="desc">История о последних действиях</p>
        </div>
        <div class="dash_list dash_list-account_history">
            <div class="row row-title">
                <div class="cell">
                    №
                </div>
                <div class="cell">
                    Действие
                </div>
                <div class="cell">
                    статус
                </div>
                <div class="cell">
                    время
                </div>
            </div>
            <?php if($history_user): ?>
                <?php $__currentLoopData = $history_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_history_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="cell">
                            <?php echo e($item_history_user->id); ?>

                        </div>
                        <div class="cell">
                            <?php echo e(__('history_users.'.$item_history_user->key_translate_language, ['number' => $item_history_user->number,
'message' => $item_history_user->message, 'walletname' => $item_history_user->wallet_name, 'namerole' => $item_history_user->name_role, 'ip' => $item_history_user->ip])); ?>

                        </div>
                        <div class="cell">
                            <?php if($item_history_user->status_view): ?>
                                <div class="status_span status_span-green">
                                    <?php echo e(__('status_view.view')); ?>

                                </div>
                            <?php else: ?>
                                <div class="status_span status_span-red">
                                    <?php echo e(__('status_view.no_view')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="cell">
                            <?php echo e($item_history_user->created_at->format('G:i:s j.m.Y')); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0577192/domains/crypto-grab.io/resources/views/user/profile.blade.php ENDPATH**/ ?>