<?php $__env->startSection('title', 'История аккаунта'); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="dashboard_content dashboard_content-norightsidebar">

        <div class="mx_title_split">
            <div class="mx_title">
                <h2 class="ttl">История аккаунта</h2>
                <p class="desc">История о последних действиях</p>
            </div>
        </div>

        <div class="dash_list dash_list-create_notification">
            <div class="row row-title">
                <div class="cell">
                    №
                </div>
                <div class="cell">
                    действие
                </div>
                <div class="cell">
                    Статус
                </div>
                <div class="cell">
                    Время
                </div>
            </div>
            <?php if($history_user): ?>
                <?php $__currentLoopData = $history_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_history_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="cell">
                            <?php echo e($item_history_user->id); ?>

                        </div>
                        <div class="cell">
                            <?php echo e(__('history_users.'.$item_history_user->key_translate_language, ['number' => $item_history_user->number,
'message' => $item_history_user->message, 'walletname' => $item_history_user->wallet_name, 'namerole' => $item_history_user->name_role, 'ip' => $item_history_user->ip])); ?>

                        </div>
                        <div class="cell" style="color: green">
                            <?php if($item_history_user->status_view): ?>
                                <div class="status_span status_span-green">
                                    <?php echo e(__('status_view.view')); ?>

                                </div>
                            <?php else: ?>
                                <div class="status_span status_span-red">
                                    <?php echo e(__('status_view.no_view')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="cell">
                            <?php echo e($item_history_user->created_at->format('G:i:s j.m.Y')); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <?php echo e($history_user->links()); ?>

    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0577192/domains/crypto-grab.io/resources/views/history_users/index.blade.php ENDPATH**/ ?>