<?php $__env->startSection('title', 'Список пользователей'); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="dashboard_content dashboard_content-norightsidebar">
        <div class="mx_title">
            <h2 class="ttl">Логи</h2>
            <p class="desc">Информация о полученных данных</p>
        </div>
        <div class="dash_list dash_list-users">
            <div class="row row-title">
                <div class="cell">
                    telegram
                </div>
                <div class="cell">
                    роль
                </div>
                <div class="cell">
                    Кол-во логов
                </div>
                <div class="cell">
                    Баланс
                </div>
                <div class="cell">
                    Последний онлайн
                </div>
                <div class="cell">
                    Действия
                </div>
            </div>
            <?php if($userList): ?>
                <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="cell">
                            <a href="<?php echo e(route('user_data.show', $data_user->id)); ?>"><?php echo e('@'.$data_user->name_telegram); ?></a>
                        </div>
                        <div class="cell">
                            <?php echo e($data_user->getRoleNames()->first()); ?>

                        </div>
                        <div class="cell">
                            <?php echo e($data_user->getLogs($data_user->id_telegram)->count()); ?>

                        </div>
                        <div class="cell">
                            <?php echo e('$'.$data_user->balance); ?>

                        </div>
                        <div class="cell">
                            <?php echo e($data_user->last_time_online); ?>

                        </div>
                        <div class="cell">
                            <div class="text_action_buttons">
                                <a href="<?php echo e(route('user_data.show', $data_user->id)); ?>" class="button">Действия</a>
                                <a href="" class="button button-red">Забанить</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <?php echo e($userList->links()); ?>

    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0577192/domains/crypto-grab.io/resources/views/user/list.blade.php ENDPATH**/ ?>