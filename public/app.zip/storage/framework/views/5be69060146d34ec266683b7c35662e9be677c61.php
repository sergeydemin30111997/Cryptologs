<?php $__env->startSection('title', 'Логи сайтов'); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('modal_create_mass_notification'); ?>
        <div class="modal_window" id="modal_create_mass_notification">
            <button class="close mx_button_act-openmodalwindow" target_modal_id="modal_create_mass_notification">x
            </button>
            <h4 class="ttl">Создание уведомления</h4>
            <form class="def_form" style="width: 343px" action="<?php echo e(route('alerts.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <p class="txt">Сообщение</p>
                <textarea type="text" name="message" class="default_input"></textarea>
                <ul class="default_selectlist">
                    <?php if($userList): ?>
                        <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="default_selectlist-item">
                                <input name="usersAlert[]" class="rchbx" type="checkbox" value="<?php echo e($userItem->id); ?>">
                                <p class="txt"><?php echo e($userItem->name_telegram); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <div class="textcheckbox_custom">
                    <input name="alertAllUsers" class="inp" type="checkbox">
                    <div class="checkbox">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                            <path d="M1.5 4.00005L4.65 7.15005L10.5 1.30005" stroke="#7E73FF" stroke-width="2"
                                  stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <p class="txt">Отправить всем</p>
                </div>
                <button type="submit" class="submit_button">Сохранить</button>
            </form>
        </div>
    <?php $__env->stopPush(); ?>
    <main class="dashboard_content dashboard_content-norightsidebar">
        <div class="mx_title_split">
            <div class="mx_title">
                <h2 class="ttl">Уведомления</h2>
                <p class="desc">Все уведомления присланные от администрации проекта</p>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_all_logs')): ?>
                <div class="mx_buttons">
                    <button class="mx_button mx_button_act-openmodalwindow"
                            target_modal_id="modal_create_mass_notification">Создать массовое уведомление
                    </button>
                </div>
            <?php endif; ?>
        </div>


        <div class="dash_list dash_list-create_notification">
            <div class="row row-title">
                <div class="cell">
                    №
                </div>
                <div class="cell">
                    Сообщение
                </div>
                <div class="cell">
                    Статус
                </div>
                <div class="cell">
                    Время
                </div>
            </div>
            <?php $__currentLoopData = $alert_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alertItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="cell">
                        <?php echo e($alertItem->id); ?>

                    </div>
                    <div class="cell">
                        <?php echo e($alertItem->message); ?>

                    </div>
                    <div class="cell" style="color: green">
                        <?php if($alertItem->status_view): ?>
                            <div class="status_span status_span-green">
                                <?php echo e(__('status_view.view')); ?>

                            </div>
                        <?php else: ?>
                            <div class="status_span status_span-red">
                                <?php echo e(__('status_view.no_view')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="cell">
                        <?php echo e($alertItem->created_at->format('G:i:s j.m.Y')); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($alert_list->links()); ?>

    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0577192/domains/crypto-grab.io/resources/views/alerts_user/index.blade.php ENDPATH**/ ?>