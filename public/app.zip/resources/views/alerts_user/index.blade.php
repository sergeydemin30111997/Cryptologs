@extends('template.app')

@section('title', 'Логи сайтов')

@section('header')

@endsection

@section('content')
    @push('modal_create_mass_notification')
        <div class="modal_window" id="modal_create_mass_notification">
            <button class="close mx_button_act-openmodalwindow" target_modal_id="modal_create_mass_notification">x
            </button>
            <h4 class="ttl">Создание уведомления</h4>
            <form class="def_form" style="width: 343px" action="{{ route('alerts.store') }}" method="POST">
                @csrf
                @method('POST')
                <p class="txt">Сообщение</p>
                <textarea type="text" name="message" class="default_input"></textarea>
                <ul class="default_selectlist">
                    @if($userList)
                        @foreach($userList as $userItem)
                            <li class="default_selectlist-item">
                                <input name="usersAlert[]" class="rchbx" type="checkbox" value="{{ $userItem->id }}">
                                <p class="txt">{{ $userItem->name_telegram }}</p>
                            </li>
                        @endforeach
                    @endif
                </ul>
                <div class="textcheckbox_custom">
                    <input name="alertAllUsers" class="inp" type="checkbox">
                    <div class="checkbox">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="9" viewBox="0 0 12 9" fill="none">
                            <path d="M1.5 4.00005L4.65 7.15005L10.5 1.30005" stroke="#7E73FF" stroke-width="2"
                                  stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <p class="txt">Отправить всем</p>
                </div>
                <button type="submit" class="submit_button">Сохранить</button>
            </form>
        </div>
    @endpush
    <main class="dashboard_content dashboard_content-norightsidebar">
        <div class="mx_title_split">
            <div class="mx_title">
                <h2 class="ttl">Уведомления</h2>
                <p class="desc">Все уведомления присланные от администрации проекта</p>
            </div>
            @can('view_all_logs')
                <div class="mx_buttons">
                    <button class="mx_button mx_button_act-openmodalwindow"
                            target_modal_id="modal_create_mass_notification">Создать массовое уведомление
                    </button>
                </div>
            @endcan
        </div>


        <div class="dash_list dash_list-create_notification">
            <div class="row row-title">
                <div class="cell">
                    №
                </div>
                <div class="cell">
                    Сообщение
                </div>
                <div class="cell">
                    Статус
                </div>
                <div class="cell">
                    Время
                </div>
            </div>
            @foreach($alert_list as $alertItem)
                <div class="row">
                    <div class="cell">
                        {{ $alertItem->id }}
                    </div>
                    <div class="cell">
                        {{ $alertItem->message }}
                    </div>
                    <div class="cell" style="color: green">
                        @if($alertItem->status_view)
                            <div class="status_span status_span-green">
                                {{ __('status_view.view') }}
                            </div>
                        @else
                            <div class="status_span status_span-red">
                                {{ __('status_view.no_view') }}
                            </div>
                        @endif
                    </div>
                    <div class="cell">
                        {{ $alertItem->created_at->format('G:i:s j.m.Y') }}
                    </div>
                </div>
            @endforeach
        </div>
        {{ $alert_list->links() }}
    </main>
@endsection
@section('footer')

@endsection
